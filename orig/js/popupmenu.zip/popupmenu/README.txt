Welcome to the Cascading Popup Menus DHTML menu system!

This ZIP file contains both the single-frame and cross-frame demonstration scripts,
and the syntax information you need to get them customised for your site.

The important files are:


POP_SYNTAX.HTML - explains the syntax of the menu creation commands, what the other
    files are, and which you need to edit. *** START BY READING THIS! ***

POPUPMENU.HTML - the single-frame demo script, with a commented tutorial.

/FRAMESET/ - the cross-frame demo script folder.

POP_HELP.HTML - Frequently Asked Questions, Known Issues, and Version History.
    Make sure you read this if you're stuck!

POP_ASSIST.HTML - A point-and-click syntax helper utility, if you're not very
    familiar with JavaScript syntax and want a menu construction program.